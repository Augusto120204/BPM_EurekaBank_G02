package ec.edu.monster.climov_eurekabank_soapjava_g02.view;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

import ec.edu.monster.climov_eurekabank_soapjava_g02.R;
import ec.edu.monster.climov_eurekabank_soapjava_g02.utils.SessionManager;

public class MenuActivity extends AppCompatActivity {
    private ImageButton btnBack;
    private MaterialButton btnRetiro;
    private MaterialButton btnTransferencia;
    private MaterialButton btnDeposito;
    private MaterialButton btnMovimientos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        initViews();

        setupListeners();
    }
    private void initViews() {
        // Buttons
        btnDeposito = findViewById(R.id.btn_deposito);
        btnRetiro = findViewById(R.id.btn_retiro);
        btnMovimientos = findViewById(R.id.btn_movimientos);
        btnTransferencia = findViewById(R.id.btn_tranferencia);
        btnBack = findViewById(R.id.btn_back);
    }

    private void setupListeners() {
        // Back button (Logout)
        btnBack.setOnClickListener(v -> logout());
        btnDeposito.setOnClickListener(v -> goToBankFunction(DepositoActivity.class));
        btnRetiro.setOnClickListener(v -> goToBankFunction(RetiroActivity.class));
        btnMovimientos.setOnClickListener(v -> goToBankFunction(MovimientosActivity.class));
        btnTransferencia.setOnClickListener(v -> goToBankFunction(TransferenciaActivity.class));
    }

    private void logout() {
        SessionManager sessionManager = new SessionManager(this);
        sessionManager.logoutUser();

        Intent intent = new Intent(MenuActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private void goToBankFunction (Class<?> pageName){
        Intent intent = new Intent(MenuActivity.this, pageName);
        startActivity(intent);
        finish();
    }
}
